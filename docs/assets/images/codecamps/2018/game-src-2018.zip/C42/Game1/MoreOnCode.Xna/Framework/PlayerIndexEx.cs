﻿using System;

using Microsoft.Xna.Framework;

namespace MoreOnCode.Xna.Framework
{
	public enum PlayerIndexEx
	{
		None = -1,
		Auto = 999,
		One = PlayerIndex.One,
		Two = PlayerIndex.Two,
		Three = PlayerIndex.Three,
		Four = PlayerIndex.Four,
	}
}

